<?php
	require "config.php";
	
	//Parameter check
	
	
	//Fetch categories from database
	
	
	//Initialize array variable
	

	//Fetch into associative array
	

	//Print array in JSON format
	
?>